﻿using BugLogThalis.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BugLogThalis.Models;
using BugLogThalis.Models.Views;
using System.Linq;
using Microsoft.AspNetCore.Http;
using System.IO;

namespace BugLogThalis.Controllers
{
    [Authorize]
    [Route("api/buglog/[controller]")]
    [ApiController]
    public class ApplicationController : ControllerBase
    {
        private readonly IApplicationService _app;
        private FileManager _fm;

        public ApplicationController(IApplicationService app, FileManager fm)
        {
            _app = app;
            _fm = fm;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            try
            {
                if (string.IsNullOrEmpty(id))
                {
                    return BadRequest("Δεν βρέθηκε η εφαρμογή");
                }

                var result = await _app.GetApplicationById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest("Σφάλμα εφαρμογής");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                if (string.IsNullOrEmpty(id))
                {
                    return BadRequest("Σφάλμα δεν υπάρχει αυτή η εφαρμογή");
                }
                var result = await _app.RemoveById(id);

                return Ok(result);
            }
            catch (Exception exc)
            {
                return BadRequest("Σφάλμα εφαρμογής");
            }
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> Update([FromBody]Application app)
        {
            try
            {
                if (app == null)
                {
                    return BadRequest("Σφάλμα");
                }

                if (app.IsValid())
                {
                    var result = await _app.Update(app);

                    return Ok(result);
                }
                else
                {
                    return BadRequest("Τα δεδομένα δεν είναι ορθά.");
                }
            }
            catch (Exception exc)
            {
                return BadRequest("Σφάλμα εφαρμογής");
            }
        }

        [HttpPost("insert")]
        public async Task<IActionResult> Insert([FromBody] Application app)
        {
            try
            {
                var result = await _app.InsertAplication(app);
                return Ok(result);
            }
            catch
            {
                return BadRequest("Σφάλμα εφαρμογής");
            }

        }

        [HttpGet("all")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var result = await _app.GetllAll();
                return Ok(result);
            }
            catch
            {
                return BadRequest("Σφάλμα εφαρμογής");
            }

        }

        [HttpGet("lookup")]
        public async Task<IActionResult> GetAllLookup()
        {
            try
            {
                var result = await _app.GetllAll();
                var lookup = result.ToList().Select(x => { return new Lookup() { Id = x.Id, Name = x.Name }; });
                return Ok(lookup);
            }
            catch
            {
                return BadRequest("Σφάλμα εφαρμογής");
            }

        }

        [HttpPost("image/application/{id}")]
        public async Task<IActionResult> AddApplicationImage([FromRoute]string id, IFormFile file)
        {
            try
            {
                string fileid = string.Empty;
                string thumbFileid = string.Empty;
                if (file.Length > 0)
                {
                    var report = await _app.GetApplicationById(id);
                    if (report == null)
                        return NotFound("Σφάλμα κατα την αποθήκευση της φωτογραφίας");

                    using (var stream = new MemoryStream())
                    {
                        await file.CopyToAsync(stream);
                        fileid = await _fm.UploadFile(file.FileName, stream);
                        stream.Position = 0;
                        //using (var ts = new MemoryStream())
                        //{
                        //    thumbFileid = await _fm.UploadFile("thumb_" + file.FileName, ts);
                        //}
                    }
                    report.ImageId = fileid;
                    await _app.Update(report);

                    return Ok(fileid);
                }
                else
                {
                    return BadRequest("Empty file");
                }
            }
            catch (Exception exc)
            {
                return BadRequest(exc.Message);
            }
        }

        [AllowAnonymous]
        [HttpGet("image/{id}")]
        public async Task<IActionResult> Get(string id)
        {
            try
            {
                var file = await _fm.GetFile(id);

                if (file == null)
                    return NotFound("File not found");

                var result = File(file.Item2, "application/octet-stream", file.Item1);

                return result;
            }
            catch (Exception exc)
            {
                return this.BadRequest(exc.Message);
            }
        }
    }
}
