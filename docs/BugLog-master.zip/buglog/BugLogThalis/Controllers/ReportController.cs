﻿using BugLogThalis.Models;
using BugLogThalis.Models.Views;
using BugLogThalis.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace BugLogThalis.Authorization
{
    [Authorize]
    [Route("api/buglog/[controller]")]
    public class ReportController : ControllerBase
    {
        private readonly IReportService _srv;
        private FileManager _fm;
        public ReportController(IReportService srv, FileManager fm)
        {
            _srv = srv;
            _fm = fm;
        }

        [HttpPost("")]
        public async Task<IActionResult> Insert([FromBody]Report re)
        {
            try
            {
                var userId = User.GetUserId();
                if (re == null)
                {
                    return BadRequest("Σφάλμα! Η αναφορά είναι κενή");
                }
                re.OnwerId = userId;
                re.OwnerFullName = User.GetUserFullname();
                if (re.IsValid())
                {
                    var result = await _srv.Insert(re);
                    return Ok(result);
                }
                else
                {
                    return BadRequest("Τα δεδομένα δεν είναι ορθά.");
                }
            }
            catch
            {
                return BadRequest("Σφάλμα εφαρμογής");
            }
        }

        [HttpPost("submit")]
        public async Task<IActionResult> Submit([FromBody]Report re)
        {
            try
            {
                var userId = User.GetUserId();
                if (re == null)
                {
                    return BadRequest("Σφάλμα! Η αναφορά είναι κενή");
                }

                if (re.IsValid())
                {
                    var result = await _srv.SubmitReport(re);
                    return Ok(result);
                }
                else
                {
                    return BadRequest("Τα δεδομένα δεν είναι ορθά.");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Σφάλμα εφαρμογής, " + ex.Message);
            }
        }

        [HttpPost("respond/{reportId}")]
        public async Task<IActionResult> RespondeToReport([FromBody]ReportAction re, string reportId)
        {
            try
            {
                var role = User.GetRole();

                if (re == null)
                {
                    return BadRequest("Σφάλμα! Η αναφορά είναι κενή");
                }
                re.UserId = User.GetUserId();
                re.AnsweredDate = DateTime.Now;
                re.UserFullname = User.GetUserFullname();
                var answer = await _srv.RespondeToReport(re, reportId, role);
                return Ok(answer);

            }
            catch (Exception ex)
            {
                return BadRequest("Σφάλμα εφαρμογής, " + ex.Message);
            }
        }

        [HttpPost("close/report/{reportId}")]
        public async Task<IActionResult> CloseReport(string reportId)
        {
            try
            {
                var userId = User.GetUserId();
                var report = await _srv.GetById(reportId);

                if (report.OnwerId != userId)
                {
                    return Unauthorized();
                }

                var result = await _srv.CloseReport(reportId, report);
                return Ok(result);

            }
            catch (Exception ex)
            {
                return BadRequest("Σφάλμα εφαρμογής, " + ex.Message);
            }
        }

        [HttpPost("open/report/{reportId}")]
        public async Task<IActionResult> OpenReport(string reportId)
        {
            try
            {
                var userId = User.GetUserId();
                var fullname = User.GetUserFullname();
                var report = await _srv.GetById(reportId);
                if(!report.IsSubmitted && report.Completed != null)
                {
                    return BadRequest("H αναφορά είναι ήδη ενεργοποιημένη");
                }
                ReportAction action = new ReportAction();
                action.UserId = userId;
                action.UserFullname = fullname;
                action.AnsweredDate = DateTime.UtcNow;
                action.Answer = "Ενεργοποίηση της αναφοράς (αυτοματοποιημένο μήνυμα).";
                if (report.OnwerId != userId)
                {
                    return Unauthorized();
                }

                var result = await _srv.OpenReport(reportId, report, action);
                return Ok(result);

            }
            catch (Exception ex)
            {
                return BadRequest("Σφάλμα εφαρμογής, " + ex.Message);
            }
        }

        [HttpPut("")]
        public async Task<IActionResult> Update([FromBody]Report re)
        {
            try
            {
                if (re == null)
                {
                    return BadRequest("Σφάλμα");
                }

                if (re.IsValid())
                {
                    var result = await _srv.Update(re);

                    return Ok(result);
                }
                else
                {
                    return BadRequest("Τα δεδομένα δεν είναι ορθά.");
                }
            }
            catch (Exception exc)
            {
                return BadRequest("Σφάλμα εφαρμογής");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                var userId = User.GetUserId();
                if (string.IsNullOrEmpty(id))
                {
                    return BadRequest("Σφάλμα");
                }
                var original = await _srv.GetById(id);

                if (original.OnwerId != userId)
                {
                    return BadRequest("Δεν έχετε δικαίωματα διαγραφής");
                }
                var result = await _srv.Delete(id);

                return Ok(result);
            }
            catch (Exception exc)
            {
                return BadRequest("Σφάλμα εφαρμογής");
            }
        }

        [HttpGet("report/{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            try
            {
                if (string.IsNullOrEmpty(id))
                {
                    return BadRequest("Σφάλμα");
                }
                var userRole = User.GetRole();
                var result = await _srv.GetById(id);
                _srv.MarkAsRead(result, userRole);
                result.ReportActions = result.ReportActions.OrderByDescending(x => x.AnsweredDate).ToList();
                return Ok(result);
            }
            catch (Exception exc)
            {
                return BadRequest("Σφάλμα εφαρμογής");
            }
        }

        [HttpGet("reports/{page}/{pagesize}/{priority}/{type}/{completed}/{order?}/{search?}")]
        public IActionResult GetPagedData(int page, int pageSize, int priority, int type, string completed, string order = "", string search = "")
        {
            try
            {
                var userId = User.GetUserId();
                DataResponse<Report> result = _srv.GetPagedData(page, pageSize, priority, type, userId, User.GetRole(), completed, order, search);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest("Σφάλμα συλλογής δεδομένων!");
            }
        }

        [HttpGet("submittedreports/{page}/{pagesize}/{priority}/{type}/{completed}/{order?}/{search?}")]
        public IActionResult GetSubmiteddData(int page, int pageSize, int priority, int type, string completed, string order = "", string search = "")
        {
            try
            {
                var role = User.GetRole();
                if (role != UserRole.Admin)
                {
                    return Unauthorized();
                }

                DataResponse<Report> result = _srv.GetSubmittedData(page, pageSize, priority, type, completed, order, search);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest("Σφάλμα συλλογής δεδομένων!");
            }
        }

        [AllowAnonymous]
        [HttpGet("image/{id}")]
        public async Task<IActionResult> Get(string id)
        {
            try
            {
                var file = await _fm.GetFile(id);

                if (file == null)
                    return NotFound("File not found");

                var result = File(file.Item2, "application/octet-stream", file.Item1);

                return result;
            }
            catch (Exception exc)
            {
                return this.BadRequest(exc.Message);
            }
        }

        [HttpPost("image/report/{id}")]
        public IActionResult AddApplicationImage(string id, [FromBody] IFormFile files)
        {
            try
            {
                string fileid = string.Empty;
                var thumbFileid = files;
                //if (file.Length > 0)
                //{
                //    var report = await _srv.GetById(id);
                //    if (report == null)
                //        return NotFound("Σφάλμα κατα την αποθήκευση της φωτογραφίας");

                //    using (var stream = new MemoryStream())
                //    {
                //        await file.CopyToAsync(stream);
                //        fileid = await _fm.UploadFile(file.FileName, stream);
                //        stream.Position = 0;
                //        //using (var ts = new MemoryStream())
                //        //{
                //        //    thumbFileid = await _fm.UploadFile("thumb_" + file.FileName, ts);
                //        //}
                //    }
                //    report.ImageId = fileid;
                //    await _srv.Update(report);

                //    return Ok(fileid);
                //}
                //else
                //{
                //    return BadRequest("Empty file");
                //}
                return Ok();
            }
            catch (Exception exc)
            {
                return BadRequest(exc.Message);
            }
        }
    }
}
