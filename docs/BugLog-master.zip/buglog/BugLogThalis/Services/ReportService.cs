﻿using BugLogThalis.DataContext;
using BugLogThalis.Models;
using BugLogThalis.Models.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BugLogThalis.Services
{
    public interface IReportService
    {
        Task<Report> Insert(Report rep);
        Task<Report> SubmitReport(Report rep);
        Task<Report> Update(Report rep);
        Task<Report> GetById(string id);
        void MarkAsRead(Report report, UserRole userRole);
        List<Report> GetAllAdmin();
        Task<bool> CloseReport(string reportId, Report report);
        Task<Report> OpenReport(string reportId, Report report, ReportAction action);
        DataResponse<Report> GetPagedData(int page, int pageSize, int priority, int type, string userId, UserRole role, string completed = "all", string order = "",
                                            string search = "");
        Task<ReportAction> RespondeToReport(ReportAction re, string reportId, UserRole role);
        DataResponse<Report> GetSubmittedData(int page, int pageSize, int priority, int type, string completed = "all", string order = "", string search = "");
        Task<bool> Delete(string id);
    }
    public class ReportService : IReportService
    {
        private Context _db;

        public ReportService(Context db)
        {
            _db = db;
        }

        public async Task<bool> Delete(string id)
        {
            var result = await _db.Report.Delete(id);
            return result;
        }

        public List<Report> GetAllAdmin()
        {
            throw new NotImplementedException();
        }

        public async Task<Report> GetById(string id)
        {
            var result = await _db.Report.GetById(id);
            return result;
        }

        public async Task<Report> Insert(Report rep)
        {
            rep.IsSubmitted = false;
            rep.HasUpdate = false;
            rep.Created = DateTime.Now;
            rep.Updated = DateTime.Now;
            var result = await _db.Report.Insert(rep);
            return result;
        }

        public async Task<Report> Update(Report rep)
        {
            var result = await _db.Report.Update(rep);
            return result;
        }

        public DataResponse<Report> GetPagedData(int page, int pageSize, int priority, int type, string userId, UserRole role, string completed = "all", string order = "",
                                                  string search = "")
        {
            IQueryable<Report> query = _db.Report.GetQuery(x => true);


            switch (completed)
            {
                case "completed":
                    query = query.Where(s => s.Completed != null);
                    break;
                case "pending":
                    query = query.Where(s => s.Completed == null);
                    break;
                default:
                    break;
            }

            switch (priority)
            {
                case 0:
                    query = query.Where(s => s.Priority == Priority.Low);
                    break;
                case 1:
                    query = query.Where(s => s.Priority == Priority.Normal);
                    break;
                case 2:
                    query = query.Where(s => s.Priority == Priority.High);
                    break;
                case 3:
                    query = query.Where(s => s.Priority == Priority.Urgent);
                    break;
                default:
                    break;
            }

            switch (type)
            {
                case 0:
                    query = query.Where(s => s.ReportType == ReportType.Bug);
                    break;
                case 1:
                    query = query.Where(s => s.ReportType == ReportType.Feature);
                    break;
                case 2:
                    query = query.Where(s => s.ReportType == ReportType.Change);
                    break;
                case 3:
                    query = query.Where(s => s.ReportType == ReportType.Support);
                    break;
                default:
                    break;
            }

            switch (order)
            {
                case "date":
                    query = query.OrderBy(x => x.SubmitDate);
                    break;
                case "date_desc":
                    query = query.OrderByDescending(x => x.SubmitDate);
                    break;
                case "application":
                    query = query.OrderBy(x => x.ApplicationId);
                    break;
                case "application_desc":
                    query = query.OrderByDescending(x => x.ApplicationId);
                    break;
                case "type":
                    query = query.OrderBy(x => x.ReportType);
                    break;
                case "type_desc":
                    query = query.OrderByDescending(x => x.ReportType);
                    break;
                default:
                    query = query.OrderByDescending(s => s.SubmitDate);
                    break;
            }
            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(t => t.Title.ToLowerInvariant().Contains(search.ToLowerInvariant()));
            }

            var rows = query.Count();

            var reports = query.Skip((page - 1) * pageSize)
                               .Take(pageSize)
                               .OrderBy(x => x.IsSubmitted)
                               .ToList();

            return new DataResponse<Report> { TotalRows = rows, Rows = reports };
        }

        public async Task<Report> SubmitReport(Report rep)
        {
            var report = await _db.Report.GetById(rep.Id);
            report.IsSubmitted = true;
            report.Notes = rep.Notes;
            report.Priority = rep.Priority;
            report.ReportType = rep.ReportType;
            report.Summary = rep.Summary;
            report.HasUpdateForReview = true;
            report.Updated = DateTime.Now;
            report.Url = rep.Url;
            report.Title = rep.Title;
            report.SubmitDate = DateTime.Now;

            var result = await _db.Report.Update(report);
            return result;
        }

        public DataResponse<Report> GetSubmittedData(int page, int pageSize, int priority, int type, string completed = "all", string order = "", string search = "")
        {
            IQueryable<Report> query = _db.Report.GetQuery(x => x.IsSubmitted);

            switch (completed)
            {
                case "completed":
                    query = query.Where(s => s.Completed != null);
                    break;
                case "pending":
                    query = query.Where(s => s.Completed == null);
                    break;
                default:
                    break;
            }

            switch (priority)
            {
                case 0:
                    query = query.Where(s => s.Priority == Priority.Low);
                    break;
                case 1:
                    query = query.Where(s => s.Priority == Priority.Normal);
                    break;
                case 2:
                    query = query.Where(s => s.Priority == Priority.High);
                    break;
                case 3:
                    query = query.Where(s => s.Priority == Priority.Urgent);
                    break;
                default:
                    break;
            }

            switch (type)
            {
                case 0:
                    query = query.Where(s => s.ReportType == ReportType.Bug);
                    break;
                case 1:
                    query = query.Where(s => s.ReportType == ReportType.Feature);
                    break;
                case 2:
                    query = query.Where(s => s.ReportType == ReportType.Change);
                    break;
                case 3:
                    query = query.Where(s => s.ReportType == ReportType.Support);
                    break;
                default:
                    break;
            }

            switch (order)
            {
                case "date":
                    query = query.OrderBy(x => x.SubmitDate);
                    break;
                case "date_desc":
                    query = query.OrderByDescending(x => x.SubmitDate);
                    break;
                case "application":
                    query = query.OrderBy(x => x.ApplicationId);
                    break;
                case "application_desc":
                    query = query.OrderByDescending(x => x.ApplicationId);
                    break;
                case "type":
                    query = query.OrderBy(x => x.ReportType);
                    break;
                case "type_desc":
                    query = query.OrderByDescending(x => x.ReportType);
                    break;
                default:
                    query = query.OrderByDescending(s => s.SubmitDate);
                    break;
            }
            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(t => t.Title.ToLowerInvariant().Contains(search.ToLowerInvariant()));
            }

            var rows = query.Count();

            var reports = query.Skip((page - 1) * pageSize)
                               .Take(pageSize)
                               .ToList();

            return new DataResponse<Report> { TotalRows = rows, Rows = reports };
        }

        public async Task<ReportAction> RespondeToReport(ReportAction re, string reportId, UserRole role)
        {
            var report = await _db.Report.GetById(reportId);

            if (role == UserRole.User)
            {
                report.HasUpdateForReview = true;
            }
            else
            {
                report.HasUpdate = true;
            }
            report.Updated = DateTime.Now;
            report.ReportActions.Add(re);
            await _db.Report.Update(report);
            return re;
        }

        public async Task<bool> CloseReport(string reportId, Report report)
        {
            report.HasUpdateForReview = true;
            report.Updated = DateTime.Now;
            report.Completed = DateTime.Now;
            await _db.Report.Update(report);
            return true;
        }

        public void MarkAsRead(Report report, UserRole userRole)
        {
            if (userRole == UserRole.Admin || userRole == UserRole.Manager)
            {
                report.HasUpdateForReview = false;
            }
            else
            {
                report.HasUpdate = false;
            }
            var task = _db.Report.Update(report);
            task.GetAwaiter();
        }

        public async Task<Report> OpenReport(string reportId, Report report, ReportAction action)
        {
            report.IsSubmitted = false;
            report.SubmitDate = null;
            report.Updated = DateTime.Now;
            report.Completed = null;
            if (action.UserId == report.OnwerId)
            {
                report.HasUpdateForReview = true;
            }
            else
            {
                report.HasUpdate = true;
            }
            report.ReportActions.Add(action);

            await _db.Report.Update(report);
            return report;
        }
    }
}
