﻿using BugLogThalis.Models.Views;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;

namespace BugLogThalis.Models
{
    public class Report : Entity
    {
        public string Title { get; set; }
        public string Summary { get; set; }
        public string Notes { get; set; }
        public string Url { get; set; }
        public List<string> Images { get; set; }
        public ReportType ReportType { get; set; }
        public Priority Priority { get; set; }
        public string ApplicationId { get; set; }

        public DateTime Created { get; set; }
        public DateTime? SubmitDate { get; set; }
        public DateTime Updated { get; set; }

        public bool HasUpdate { get; set; }
        public bool HasUpdateForReview { get; set; }
        public bool IsSubmitted { get; set; }
        public DateTime? Completed { get; set; }


        public string OnwerId { get; set; }
        public string OwnerFullName { get; set; }

        public List<ReportAction> ReportActions { get; set; }

        public Report()
        {
            ReportActions = new List<ReportAction>();
            Images = new List<string>();
        }
    }

    public enum ReportType
    {
        Bug,
        Feature,
        Change,
        Support,
        All
    }

    public enum Priority
    {
        Low,
        Normal,
        High,
        Urgent,
        All
    }

    public class ReportAction
    {
        public DateTime AnsweredDate { get; set; }
        public string Answer { get; set; }
        public string UserId { get; set; }
        public string UserFullname { get; set; }
    }
}
