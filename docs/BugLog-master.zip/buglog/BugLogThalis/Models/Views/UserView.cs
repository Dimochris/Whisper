﻿namespace BugLogThalis.Models.Views
{
    public class UserView
    {
        public string Fullname { get; set; }

        public UserView() { }

        public UserView(User user) {
            Fullname = string.Join(" ", new string[] { user.Lastname, user.Name });
        }
    }
}
