﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BugLogThalis.Models.Views
{
    public class Lookup : IEquatable<Lookup>
    {
        public string Id { get; set; }
        public string Name { get; set; }

        public bool Equals(Lookup other)
        {
            if (other == null)
            {
                return false;
            }
            if (this.Id == other.Id)
            {
                return true;
            }
            return false;
        }
    }
}
