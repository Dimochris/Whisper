import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { LoaderService } from './loader.service';
import { NotifyService } from './notify.service';
import { PaginationService } from './pagination.service';
import { UtilityService } from './utility.service';

@NgModule({
  imports: [
    CommonModule,
    AngularMultiSelectModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    NgbModule.forRoot(),
    HttpClientModule
  ],
  declarations: [],
  providers: [
    LoaderService,
    NotifyService,
    UtilityService,
    PaginationService
  ], exports: [
    CommonModule,
    AngularMultiSelectModule,
    FormsModule,
    NgbModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    HttpClientModule
  ],

})
export class SharedModule { }
