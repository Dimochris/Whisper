import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError as observableThrowError, Observable, BehaviorSubject } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { JwtHelperService } from '@auth0/angular-jwt';
import { environment } from '../../environments/environment';
import { User, UserRole } from '../../app/user/user';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  jwt = new JwtHelperService();
  private userUrl = environment.api + 'user';
  private authUrl = environment.api + 'auth/token';

  constructor(private router: Router, private http: HttpClient) {
    this.initAuthorization();
  }

  private loggedInSubject$ = new BehaviorSubject<boolean>(false);
  loggedIn$ = this.loggedInSubject$.asObservable();

  private isAdminSubject$ = new BehaviorSubject<boolean>(false);
  isAdmin$ = this.isAdminSubject$.asObservable();

  private userInSubject$ = new BehaviorSubject<User>(new User());
  user$ = this.userInSubject$.asObservable();

  get isAdmin(): boolean { return this.isAdminSubject$.getValue(); }
  set isAdmin(value: boolean) { this.isAdminSubject$.next(value); }

  get loggedIn(): boolean { return this.loggedInSubject$.getValue(); }
  set loggedIn(value: boolean) { this.loggedInSubject$.next(value); }

  get user(): User { return this.userInSubject$.getValue(); }
  set user(value: User) { this.userInSubject$.next(value); }

  register(user: User) {
    return this.http.post<any>(`${this.userUrl}/register`, user)
      .pipe(catchError(this.errorHandler));
  }

  validate(user: string) {
    return this.http.post<any>(`${this.userUrl}/register`, user)
      .pipe(catchError(this.errorHandler));
  }

  getToken() { return localStorage.getItem('thalesToken'); }

  get isAuthanticated(): boolean { return !this.jwt.isTokenExpired(this.getToken()); }

  login(username: string, password: string): Observable<boolean> {
    const body: any = { Username: username, Password: password };
    return this.http.post(this.authUrl, body)
      .pipe(map((data: any) => {
        const token = data['token'];
        if (token) {
          localStorage.setItem('thalesToken', token);
          this.initializeUser(token);
          this.loggedIn = true;
          return true;
        } else {
          return false;
        }
      }));
  }

  initAuthorization() {
    this.loggedIn = this.isAuthanticated;
    if (this.loggedIn) {
      this.initializeUser(this.getToken());
    } else {
      localStorage.removeItem('token');
    }
  }

  initializeUser(token: any) {
    if (!token) { return; }
    const info = this.jwt.decodeToken(token);
    this.user.id = info.Id;
    this.user.name = info.Name;
    this.user.lastname = info.Lastname;
    this.user.username = info.Username;
    this.user.role = this.getRoleFromToken(info);
    this.isAdmin = UserRole.Admin === this.user.role;
  }

  getRoleFromToken(token: any): UserRole {
    if (token.Admin) { return UserRole.Admin; }
    if (token.Manager) { return UserRole.Manager; }
    if (token.User) { return UserRole.User; }
  }

  logout() {
    localStorage.removeItem('thalesToken');
    this.loggedIn = false;
    this.router.navigate(['/login']);
  }

  // Common method for http errors handler
  errorHandler(error: HttpErrorResponse) {
    return observableThrowError(error || 'Server Error');
  }
}
