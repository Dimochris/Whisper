import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { Routes, RouterModule } from '@angular/router';
import { ListApplicationComponent } from './application-list/application-list.component';
import { EditApplicationComponent } from './application-details/application-details.component';

import { AuthGuard } from '../auth/auth.guard';
import { IsAdminGuard } from '../auth/isAdmin.guard';
const routes: Routes = [
  { path: 'application', component: ListApplicationComponent, canActivate: [AuthGuard, IsAdminGuard] },
  { path: 'application/new', component: EditApplicationComponent, canActivate: [AuthGuard, IsAdminGuard] },
  { path: 'application/:id', component: EditApplicationComponent, canActivate: [AuthGuard, IsAdminGuard] },
];

@NgModule({
  imports: [
    SharedModule, RouterModule.forChild(routes)
  ],
  declarations: [ListApplicationComponent, EditApplicationComponent]
})
export class GroupsModule { }
