export class Application {
    id: string;
    name: string;
    imageId: string;
    description: string;
    created: number;
    updated: Date;
}
