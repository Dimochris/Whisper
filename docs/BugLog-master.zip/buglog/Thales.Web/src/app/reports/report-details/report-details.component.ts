import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

import { ReportsService } from '../reports.service';
import { LoaderService } from '../../shared/loader.service';
import { NotifyService } from '../../shared/notify.service';

import introJs from '../../../../node_modules/intro.js/intro.js';

import { Report, ReportAction } from '../report';
import { ApplicationService } from '../../application/application.service';
import { Application } from '../../application/application';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-report-details',
  templateUrl: './report-details.component.html',
  styleUrls: ['./report-details.component.sass']
})
export class ReportDetailsComponent implements OnInit {
  filesUrl = `${environment.api}report/`;
  imageUrl = `${environment.api}report/image/`;
  report = new Report();
  answer = new ReportAction();
  applications = new Array<Application>();
  // Reactive Form Item
  reportForm: FormGroup;
  imageSrc: any;
  previewImages = new Array<any>();
  files: any;
  mylocation: any;


  formErrors = {
    'title': '',
    'summary': ''
  };
  validationMessages = {
    'title': {
      'required': 'O τίτλος είναι υποχρεωτικός',
      'maxlength': 'Το Όνομα πρέπει να είναι (50) χαρακτήρες!'
    },
    'summary': {
      'required': 'Η περίγραφη  έιναι υποχρεωτική.'
    }
  };

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private loader: LoaderService,
    private notify: NotifyService,
    private reportService: ReportsService,
    private router: Router,
    private applicationService: ApplicationService,
    private location: Location
  ) {
    this.createForm();
  }

  private createForm() {
    this.reportForm = this.fb.group({
      title: [this.report.title, Validators.compose([
        Validators.required,
        Validators.maxLength(50)])
      ],
      summary: [this.report.summary, Validators.compose([Validators.required])],
      applicationId: [this.report.applicationId],
      reportType: [this.report.reportType],
      priority: [this.report.priority],
      url: [this.report.url],
      notes: [this.report.notes]
    });
    this.reportForm.valueChanges.subscribe(value => (this.onValueChanged(value)));
    this.onValueChanged();
  }

  respondeToReport() {
    this.loader.show();
    this.reportService.respondeToReport(this.answer, this.report.id).subscribe(res => {
      this.answer = new ReportAction();
      this.report.reportActions.unshift(res);
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }

  openReport(){
    this.loader.show();
    this.reportService.openReport(this.report.id).subscribe(res => {
      this.notify.success('H Αναφορά Ενεργοποιήθηκε.');
      this.report = res;
      this.createForm();
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }
  completeReport() {
    this.loader.show();
    this.reportService.closeReport(this.report.id).subscribe(res => {
      this.report.completed= new Date();
      this.notify.success('H Αναφορά έκλεισε.')
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }

  onValueChanged(value?: any) {
    if (!this.reportForm) { return; }
    const form = this.reportForm;
    for (const field in this.formErrors) {
      if (field) {
        this.formErrors[field] = '';
        const control = form.get(field);
        if (value === 'submit') {
          control.markAsDirty();
        }
        if (control && control.dirty && !control.valid) {
          const messages = this.validationMessages[field];
          for (const key in control.errors) {
            if (key) {
              this.formErrors[field] += messages[key] + ' ';
            }
          }
        }
      }
    }
  }

  onSend() {
    const model = this.reportForm.value;
    this.report.title = model.title;
    this.report.summary = model.summary;
    this.report.reportType = model.reportType;
    this.report.priority = model.priority;
    this.report.applicationId = model.applicationId;
    this.report.url = model.url;
    this.report.notes = model.notes;
    this.report.id ? this.update() : this.insert();
  }

  onSubmit() {
    const model = this.reportForm.value;
    this.report.title = model.title;
    this.report.summary = model.summary;
    this.report.reportType = model.reportType;
    this.report.priority = model.priority;
    this.report.applicationId = model.applicationId;
    this.report.url = model.url;
    this.report.notes = model.notes;
    this.submitReport();
  }

  submitReport() {
    this.loader.show();
    this.reportService.submitReport(this.report).subscribe(res => {
      if (this.files) {
        this.reportService.makeFileRequest(`${this.filesUrl}image/report/${res.id}`, this.files).subscribe(images => {
          this.report.images = images;
        });
      }
      this.report = res;
      this.notify.success();
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }

  ngOnInit() {
    this.getApplications();
    this.route.params.subscribe((param) => {
      const id = param['id'];
      if (id === 'demo') {
        this.startTour();
      } else if (id !== 'new') {
        this.getReport(id);
      }
    });
  }

  getApplications() {
    this.loader.show();
    this.applicationService.getApplications().subscribe(res => {
      this.applications = res;
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }

  update() {
    this.loader.show();
    this.reportService.updateReport(this.report).subscribe(res => {
      if (this.files) {
        this.reportService.makeFileRequest(`${this.filesUrl}image/report/${res.id}`, this.files).subscribe(images => {
          this.report.images = images;
        });
      }
      this.report = res;
      this.notify.success();
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }

  getReport(id: string) {
    this.loader.show();
    this.reportService.getReport(id).subscribe(res => {
      this.report = res;
      this.createForm();
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }

  insert() {
    this.loader.show();
    this.reportService.insertReport(this.report).subscribe(res => {
      if (this.files) {
        this.reportService.makeFileRequest(`${this.filesUrl}image/report/${res.id}`, this.files).subscribe((images: string[]) => {
          this.report.images = images;
        });
      }
      this.report = res;
      this.location.go('report/' + res.id);
      this.notify.success();
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }

  removeImage(i: number) {
    this.previewImages.splice(i, 1);
  }

  getApplicationName() {
    const app = this.applications.find(x => x.id === this.reportForm.value.applicationId);
    return app ? app.name : '';
  }

  onChange(event: any) {
    if (event.srcElement) {
      if (event.srcElement.files.length < 1) { return; }
      this.files = event.srcElement.files;
    } else if (event.originalTarget) {
      if (event.originalTarget.files.length < 1) { return; }
      this.files = event.originalTarget.files;
    }
    for (let i = 0; i < this.files.length; i++) {
      const reader = new FileReader();
      reader.onload = e => this.previewImages.push(reader.result);
      reader.readAsDataURL(this.files[i]);
    }

  }

  delete() {
    this.loader.show();
    this.reportService.deleteReport(this.report.id).subscribe(res => {
      this.router.navigate(['/reports', '1', '10', '4', '4', 'all', 'date']);
      this.notify.success('Η διαγραφή ολοκληρώθηκε');
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }


  startTour() {
    introJs().setOption('exitOnOverlayClick', 'false').setOptions({
      steps: [
        {
          intro: 'Καλως ήλθατε στην δημιουργία νέου αιτήματος!',
          position: 'left'

        }, {
          element: '#heading1',
          intro: 'Στο πεδίο Εφαρμογή επιλέγουμε την εφαρμογή για την οποία ενδιαφερόμαστε ',
          position: 'right'
        }, {
          element: '#heading2',
          intro: 'Υποχρεωτικό πεδιό: Σε αυτο το πεδίο αναγράφουμε τον τίτλο της αναφοράς μας',
          position: 'right'
        }, {
          element: '#heading3',
          intro: 'Υποχρεωτικό πεδιό: Σε αυτο το πεδίο αναγράφουμε μια σύντομη περιγραφή του θέματος που επιθυμούμε να αναφέρουμε',
          position: 'right'
        },
        {
          element: '#heading4',
          intro: 'Σε αυτο το πεδίο αναγράφουμε κάποιο σχολιασμό ή λεπτομέριες που θέλουμε ο διαχειριστής να λάβει υπόψιν του',
          position: 'right'
        },
        {
          element: '#heading5',
          intro: 'Επιλέγουμε το είδος της αναφοράς.',
          position: 'right'
        },
        {
          element: '#heading6',
          intro: ' Επιλέγουμε την πρoτεραιότητα που θέλουμε να αποδόσουμε στην αναφορά μας',
          position: 'right'
        },
        {
          element: '#heading7',
          intro: ' Αντιγράφουμε το URL (διεύθυνση στον φυλλομετριτή μας) και την τοποθετούμε στο παραπάνω πεδίο',
          position: 'right'
        },
        {
          element: '#heading8',
          intro: ' Επιλεγουμε μία εικόνα στην οποία εμφανίζετε το περιεχόμενο για το οποίο αιτούμαστε ',
          position: 'right'
        },
        {
          element: '#heading9',
          intro: ' Υποβάλουμε την αναφορά μας ώστε η ομάδα του ΓΕΑ/ΚΜΗ να το επεξεργαστεί κατάλληλα ',
          position: 'right'
        },
        {
          element: document.querySelectorAll('.heading')[2],
          intro: ' Επιστροφή στην κεντρική σελίδα',
          position: 'right'
        }
      ]
    }).start().onexit(() => {
      this.router.navigate(['home']);
    });
  }
  backUrl() {
    this.router.navigate(['/reports', '1', '10', '4', '4', 'pending', 'date']);
  }
}

