import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';

import { ReportsService } from '../reports.service';
import { LoaderService } from '../../shared/loader.service';
import { NotifyService } from '../../shared/notify.service';

import { Report, ReportAction } from '../report';
import { ApplicationService } from '../../application/application.service';
import { Application } from '../../application/application';
@Component({
  selector: 'app-submitted-report',
  templateUrl: './submitted-report.component.html',
  styleUrls: ['./submitted-report.component.sass']
})
export class SubmittedReportComponent implements OnInit {
  report: Report;
  applications = new Array<Application>();
  answer = new ReportAction();
  constructor(
    private route: ActivatedRoute,
    private loader: LoaderService,
    private notify: NotifyService,
    private reportService: ReportsService,
    private router: Router,
    private applicationService: ApplicationService,
    private location: Location) { }

  ngOnInit() {
    this.getApplications();
    this.route.params.subscribe((param) => {
      const id = param['id'];
      if (id !== 'new') {
        this.getReport(id);
      }
    });
  }
  getReport(id: string) {
    this.loader.show();
    this.reportService.getReport(id).subscribe(res => {
      this.report = res;
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }
  backToTable() {
    this.router.navigate(['/submittedreports', '1', '10', '4', '4', 'pending', 'date'])
  }

  respondeToReport() {
    this.loader.show();
    this.reportService.respondeToReport(this.answer, this.report.id).subscribe(res => {
      this.answer = new ReportAction();
      this.report.reportActions.unshift(res);
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }

  getApplicationName(id) {
    const app = this.applications.find(x => x.id === id);
    return app ? app.name : '';
  }

  getApplications() {
    this.loader.show();
    this.applicationService.getApplications().subscribe(res => {
      this.applications = res;
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }
  backUrl() {
    this.router.navigate(['/reports', '1', '10', '4', '4', 'all', 'date']);
  }
}
