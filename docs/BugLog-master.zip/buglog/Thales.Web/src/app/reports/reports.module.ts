import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { Routes, RouterModule } from '@angular/router';

import { ReportsListComponent } from './reports-list/reports-list.component';
import { ReportDetailsComponent } from './report-details/report-details.component';

import { AuthGuard } from '../auth/auth.guard';
import { SubmittedReportsComponent } from './submitted-reports/submitted-reports.component';
import { SubmittedReportComponent } from './submitted-report/submitted-report.component';

const routes: Routes = [
  { path: 'reports/:page/:pagesize/:priority/:type/:completed/:order', component: ReportsListComponent, canActivate: [AuthGuard] },
  { path: 'reports/:page/:pagesize/:priority/:type/:completed/:order/:search', component: ReportsListComponent, canActivate: [AuthGuard] },
  { path: 'report/:id', component: ReportDetailsComponent, canActivate: [AuthGuard] },
  {
    path: 'submittedreports/:page/:pagesize/:priority/:type/:completed/:order',
    component: SubmittedReportsComponent, canActivate: [AuthGuard]
  },
  {
    path: 'submittedreports/:page/:pagesize/:priority/:type/:completed/:order/:search',
    component: SubmittedReportsComponent, canActivate: [AuthGuard]
  },
  { path: 'submittedreports/:id', component: SubmittedReportComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ],
  declarations: [
    ReportsListComponent,
    ReportDetailsComponent,
    SubmittedReportsComponent,
    SubmittedReportComponent
  ]
})
export class ReportsModule { }
