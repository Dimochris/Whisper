import { Component, OnInit, OnDestroy } from '@angular/core';

import { ReportsService } from '../reports.service';
import { LoaderService } from '../../shared/loader.service';
import { NotifyService } from '../../shared/notify.service';
import { Report, ReportType } from '../report';
import { PaginationService } from '../../shared/pagination.service';
import { Location } from '@angular/common';
import { ApplicationService } from 'src/app/application/application.service';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-submitted-reports',
  templateUrl: './submitted-reports.component.html',
  styleUrls: ['./submitted-reports.component.sass']
})
export class SubmittedReportsComponent implements OnInit, OnDestroy {
  private subscriptions = new Array<Subscription>();
  totalRows: number;
  applicationList = [];
  reportState: string;
  page = 1;
  pageSize = 10;
  order = 'date';
  search = '';
  type = 4;
  priority = 4;
  pages: Array<number>;
  totalPages: number;
  rows = new Array<Report>();

  constructor(
    private reportService: ReportsService,
    private appService: ApplicationService,
    private pagerService: PaginationService,
    private notify: NotifyService,
    private location: Location,
    private route: ActivatedRoute,
    private loader: LoaderService,
    private router: Router
  ) { }
  ngOnInit() {
    this.subscriptions.push(this.route.params.subscribe(params => {
      if (params) {
        this.pageSize = +params['pagesize'];
        this.page = +params['page'];
        this.order = params['order'];
        this.priority = params['priority'];
        this.type = params['type'];
        this.reportState = params['completed'];
      }
    }));
    this.getApplications();
    this.getReports();
  }

  ngOnDestroy() {
    for (const subscription of this.subscriptions) { subscription.unsubscribe(); }
  }

  searchTitle(value) {
    this.search = value;
    this.getReports(true);
  }
  getReports(searching: boolean = false) {
    this.loader.show();
    this.setUrl();
    // tslint:disable-next-line:max-line-length
    this.reportService.getSubmittedReports(this.page, this.pageSize, this.priority, this.type, this.reportState, this.order, this.search).subscribe(res => {
      this.loader.hide();
      this.rows = res.rows;
      this.page = searching ? 1 : this.page;
      this.totalPages = Math.ceil(res.totalRows / this.pageSize);
      this.pages = this.pagerService.getPages(this.totalPages, this.page);
      this.search = '';
      this.setUrl();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }

  setUrl() {
    this.location.go(`/submittedreports/${this.page}/${this.pageSize}/${this.priority}/${this.type}/${this.reportState}/` +
      `${this.order}/${this.search}`);
  }
  getType(t: number) {
    return ReportType[t];
  }

  setPage(p: number) {
    if (p === this.page) {
      return;
    }
    this.page = p;
    this.getReports();
  }

  nextPage() {
    if (this.page === this.totalPages) {
      return;
    }
    this.page += 1;
    this.getReports();
  }

  previousPage() {
    if (this.page === 1) {
      return;
    }
    this.page -= 1;
    this.getReports();
  }

  firstPage() {
    if (this.page === 1) {
      return;
    }
    this.page = 1;
    this.getReports();
  }

  lastPage() {
    if (this.page === this.totalPages) {
      return;
    }
    this.page = this.totalPages;
    this.getReports();
  }

  orderBy(order: string) {
    if (order === this.order) {
      this.order = order + '_desc';
    } else {
      this.order = order;
    }
    this.getReports();
  }

  getNameOfApp(id: any) {
    if (!id) { return; }
    const t = this.applicationList.find(x => x.id === id);
    if (t) { return t.name; }
  }

  getApplications() {
    this.loader.show();
    this.appService.getApplicationsLookup().subscribe(res => {
      this.loader.hide();
      this.applicationList = res;
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }

  openReport(id: string) {
    this.router.navigate(['/submittedreports', id]);

  }

}
