import { Application } from '../application/application';

export class Report {
    id: string;
    title: string;
    summary: string;
    notes: string;
    url: string;
    images: Array<string>;
    applicationId: string;
    reportType: ReportType = 0;
    priority: Priority = 0;

    application: Application;

    created: Date;
    submitDate: Date;
    updated: Date;

    hasUpdate: boolean;
    hasUpdateForReview: boolean;
    isSubmitted: boolean;
    completed: Date;

    OnwerId: string;
    ownerFullName: string;
    reportActions: Array<ReportAction>;
    constructor() {
        this.application = new Application();
        this.images = new Array<string>();
        this.reportActions = new Array<ReportAction>();
    }

}

export enum Priority {
    Χαμηλό,
    Μεσαίο,
    Υψηλό,
    Επείγον,
    Όλα
}

export enum ReportType {
    Bug,
    Feature,
    Change,
    Support,
    All
}

export class ReportAction {
    answeredDate: Date;
    answer: string;
    userId: string;
    userFullname: string;
}
