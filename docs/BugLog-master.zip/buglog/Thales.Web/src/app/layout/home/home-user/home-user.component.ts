import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthService } from '../../../auth/auth.service';
import { LoaderService } from 'src/app/shared/loader.service';
import { NotifyService } from 'src/app/shared/notify.service';
import { ApplicationService } from 'src/app/application/application.service';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-home-user',
  templateUrl: './home-user.component.html',
  styleUrls: ['./home-user.component.sass']
})
export class HomeUserComponent implements OnInit, OnDestroy {
  private subscriptions = new Array<Subscription>();
  imageUrl = `${environment.api}application/image/`;
  isAdmin = false;
  apps = new Array<any>();
  constructor(
    private auth: AuthService,
    private application: ApplicationService,
    private loader: LoaderService,
    private notify: NotifyService
  ) { }

  ngOnInit() {
    this.getApplications();
    this.subscriptions.push(this.auth.isAdmin$.subscribe(isAdmin => {
      this.isAdmin = isAdmin;
    }));
  }
  ngOnDestroy() {
    this.subscriptions.forEach(subscription => subscription.unsubscribe());
  }

  getApplications() {
    this.loader.show();
    this.application.getApplications().subscribe(res => {
      this.apps = res;
      this.loader.hide();
    }, error => {
      this.notify.error(error);
      this.loader.hide();
    });
  }
}
