import { Component, OnInit } from '@angular/core';
import {HomeUserComponent} from './home-user/home-user.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.sass']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
