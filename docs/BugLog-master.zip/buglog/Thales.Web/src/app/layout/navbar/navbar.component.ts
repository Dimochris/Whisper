import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthService } from '../../auth/auth.service';
import { User } from '../../user/user';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.sass']
})
export class NavbarComponent implements OnInit, OnDestroy {
  private subscriptions = new Array<Subscription>();
  user = new User();
  loggedIn = false;
  isAdmin = false;

  constructor(
    private auth: AuthService
  ) { }

  ngOnDestroy() {
    this.subscriptions.forEach(subscription => subscription.unsubscribe());
  }

  ngOnInit() {
    this.subscriptions.push(this.auth.loggedIn$.subscribe(loggedIn => {
      this.loggedIn = loggedIn;
    }));
    this.subscriptions.push(this.auth.isAdmin$.subscribe(isAdmin => {
      this.isAdmin = isAdmin;
    }));
    this.subscriptions.push(this.auth.user$.subscribe((user) => {
      this.user = user;
    }));
  }

  logout() {
    this.auth.logout();
  }

  getNameOfRole(role: number) {
    if (role === 0) { return 'Διαχειριστής'; }
    if (role === 0) { return 'Διαχειριστής Εφαρμογών'; }
    return 'Χρήστης Εφαρμογής';
  }

}
