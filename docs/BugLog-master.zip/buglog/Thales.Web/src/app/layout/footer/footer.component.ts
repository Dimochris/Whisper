import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.sass']
})
export class FooterComponent implements OnInit {

  constructor() { }
  yearnow = new Date();
  yearStart = new Date('Dec 22, 2018 00:00:00');
  takeyear () {
     return (this.yearStart.getFullYear() - this.yearnow.getFullYear() === 0 ? this.yearStart.getFullYear()
     : ( `${this.yearStart.getFullYear()} - ${this.yearnow.getFullYear()}`));
  }
  ngOnInit() {
  }

}
