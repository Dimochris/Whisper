import { Component, OnInit } from '@angular/core';

import { AuthService } from '../../auth/auth.service';
import { LoaderService } from 'src/app/shared/loader.service';
import { NotifyService } from 'src/app/shared/notify.service';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.sass']
})
export class PasswordComponent implements OnInit {
  showPassword = false;
  passwordCheck: string;
  usernameValidate: string;
  emailIsValid = false;

  ngOnInit(): void {

  }

  constructor(
    private auth: AuthService,
    private loader: LoaderService,
    private notify: NotifyService
  ) { }

  retrivePassword() {
    this.loader.show();
    this.auth.validate(this.usernameValidate).subscribe(res => {
      this.loader.hide();
    }, error => {
      this.notify.error(error);
      this.loader.hide();
    });
  }


}
