import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError as observableThrowError } from 'rxjs';
@Injectable({
    providedIn: 'root'
})
export class LayoutService {

    constructor(private http: HttpClient) { }

    errorHandler(error: HttpErrorResponse) {
        return observableThrowError(error || 'Server Error');
    }
}
