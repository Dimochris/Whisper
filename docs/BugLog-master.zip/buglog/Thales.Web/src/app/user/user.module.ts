import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { Routes, RouterModule } from '@angular/router';

import { UserListComponent } from './user-list/user-list.component';
import { UserDetailsComponent } from './user-details/user-details.component';

import { AuthGuard } from '../auth/auth.guard';
import { IsAdminGuard } from '../auth/isAdmin.guard';
import { UserProfileComponent } from './user-profile/user-profile.component';

const routes: Routes = [
  { path: 'users', component: UserListComponent, canActivate: [AuthGuard, IsAdminGuard] },
  { path: 'user/profile', component: UserProfileComponent, canActivate: [AuthGuard, AuthGuard] },
  { path: 'user/:id', component: UserDetailsComponent, canActivate: [AuthGuard, IsAdminGuard] }

];


@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ],
  declarations: [UserListComponent, UserDetailsComponent, UserProfileComponent]
})

export class UserModule { }
