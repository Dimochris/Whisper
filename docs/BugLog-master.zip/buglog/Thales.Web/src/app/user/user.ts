export class User {
    name: string;
    lastname: string;
    username: string;
    isActive: Activated;
    role: UserRole;
    password: string;
    id: string;
    applications: Array<Lookup>;

    constructor() {
        this.applications = new Array<Lookup>();
    }
}
export class Lookup {
    id: string;
    name: string;
}

export class Profile {
    name: string;
    lastname: string;
    username: string;
    roleName: string;
    role: number;
    totalReports: number;
    email: string;
    phone: string;
    reports: number;
    answers: number;

}


export enum Activated {
    No,
    Yes,
    All
}


export enum UserRole {
    Admin,
    User,
    Manager
}
export class testclass {

}