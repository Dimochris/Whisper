import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from '../user';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Location } from '@angular/common';

import { UserService } from '../user.service';
import { LoaderService } from '../../shared/loader.service';
import { NotifyService } from '../../shared/notify.service';
import { ApplicationService } from 'src/app/application/application.service';




@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.sass']
})
export class UserDetailsComponent implements OnInit {
  applicationList = [];
  dropdownSettings = {
    singleSelection: false,
    text: 'Επιλογή Διαχείρισης Εφαρμογών',
    selectAllText: 'Επιλογή Όλων',
    labelKey: 'name',
    unSelectAllText: 'Αποεπιλογή Όλων',
    enableSearchFilter: true,
    classes: 'myclass custom-class'
  };
  user = new User();
  userForm: FormGroup;

  formErrors = {
    'name': '',
    'lastname': '',
    'username': '',
    'password': ''
  };

  validationMessages = {
    'name': {
      'required': 'Το Όνομα είναι υποχρεωτικός',
      'maxlength': 'Το Όνομα έχει όριο (50) χαρακτήρων'
    },
    'lastname': {
      'required': 'Το Επίθετο έιναι υποχρεωτικό.',
      'maxlenght': 'To Eπίθετο έχει όριο (50) χαρακτήρων'
    },
    'username': {
      'required': 'Το username είναι υποχρεωτικό'
    },
    'password': {
      'required': 'Ο κωδικός είναι υποχρεωτικός'
    }
  };

  onDeSelectAll(items: any) {
    this.user.applications = [];
  }
  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private loader: LoaderService,
    private notify: NotifyService,
    private userService: UserService,
    private location: Location,
    private router: Router,
    private appService: ApplicationService
  ) {
    this.userForm = this.fb.group({
      name: [this.user.name, Validators.compose([
        Validators.required,
        Validators.maxLength(50)
      ])],
      lastname: [this.user.lastname, Validators.compose([
        Validators.required, Validators.maxLength(50)
      ])],
      username: [this.user.username, Validators.required],
      isActive: [this.user.isActive],
      role: [this.user.role],
      password: [this.user.password, Validators.required]
    });
  }


  ngOnInit() {
    this.getApplications();
    this.route.params.subscribe((param) => {
      const id = param['id'];
      if (id !== 'new') {
        this.getUser(id);
      } else if (id === 'new') {
        this.createForm();
      }
    });
  }


  getUser(id: string) {
    this.loader.show();
    this.userService.getUser(id).subscribe(res => {
      this.user = res;
      this.createForm();
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }

  createForm() {
    this.userForm = this.fb.group({
      name: [this.user.name, Validators.compose([
        Validators.required,
        Validators.maxLength(50)
      ])],
      lastname: [this.user.lastname, Validators.compose([
        Validators.required, Validators.maxLength(50)
      ])],
      username: [this.user.username, Validators.required],
      isActive: [this.user.isActive],
      role: [this.user.role],
      password: [this.user.password, this.user.id ? Validators.required : null]
    });
    this.userForm.valueChanges.subscribe(value => (this.onValueChanged(value)));
  }


  onValueChanged(value?: any) {
    if (!this.userForm) { return; }
    const form = this.userForm;
    for (const field in this.formErrors) {
      if (field) {
        this.formErrors[field] = '';
        const control = form.get(field);
        if (value === 'submit') {
          control.markAsDirty();
        }
        if (control && control.dirty && !control.valid) {
          const messages = this.validationMessages[field];
          for (const key in control.errors) {
            if (key) {
              this.formErrors[field] += messages[key] + ' ';
            }
          }
        }
      }
    }
  }

  onSend() {
    const model = this.userForm.value;
    this.user.name = model.name;
    this.user.lastname = model.lastname;
    this.user.username = model.username;
    this.user.isActive = model.isActive;
    this.user.role = model.role;
    this.user.password = model.password;
    this.user.id ? this.update() : this.insert();

  }


  update() {
    this.loader.show();
    this.userService.updateUser(this.user).subscribe(res => {
      this.user = res;
      this.notify.success();
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }

  insert() {
    this.loader.show();
    this.userService.insertUser(this.user).subscribe(res => {
      this.user = res;
      this.location.go('user/' + res.id);
      this.notify.success();
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }


  delete() {
    this.loader.show();
    this.userService.deleteUser(this.user.id).subscribe(res => {
      this.router.navigate(['/user']);
      this.notify.success('Η διαγραφή ολοκληρώθηκε');
      this.loader.hide();
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }

  getApplications() {
    this.loader.show();
    this.appService.getApplicationsLookup().subscribe(res => {
      this.loader.hide();
      this.applicationList = res;
    }, error => {
      this.loader.hide();
      this.notify.error(error);
    });
  }
}
