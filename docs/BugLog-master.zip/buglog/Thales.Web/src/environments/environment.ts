export const environment = {
  production: false,
  // api: 'http://192.168.48.62:4280/api/',
  api: 'http://localhost:5200/api/buglog/'
};
