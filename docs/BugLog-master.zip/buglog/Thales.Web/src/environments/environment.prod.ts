export const environment = {
  production: true,
  api: 'https://11.1.9.105:9200/api/buglog/'
};
