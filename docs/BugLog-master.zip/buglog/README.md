# BugLog

An application to manage bugs for other applications.
Provides three different level of users.